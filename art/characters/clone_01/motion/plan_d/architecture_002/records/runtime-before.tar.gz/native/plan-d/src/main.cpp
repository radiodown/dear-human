#include "Renderer.hpp"
#include <SDL3/SDL_main.h>
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <memory>
#include <stdexcept>
#include <string>

namespace {
struct Options {
    dh::ViewState state;
    std::filesystem::path capture;
    int frames{};
};
Options parse(int argc,char** argv) {
    Options options;
    const auto value=[&](int& i) -> std::string {
        if(++i>=argc) throw std::runtime_error(std::string("Missing value after ")+argv[i-1]);
        return argv[i];
    };
    for(int i=1;i<argc;++i) {
        const std::string argument=argv[i];
        if(argument=="--view") {
            const auto mode=value(i);
            if(mode=="bones") options.state.view=dh::View::Skeleton;
            else if(mode=="solid") options.state.view=dh::View::Solid;
            else if(mode=="overlay") options.state.view=dh::View::Overlay;
            else throw std::runtime_error("--view expects bones, solid or overlay");
        } else if(argument=="--capture") options.capture=value(i);
        else if(argument=="--frames") {
            options.frames=std::stoi(value(i));
            if(options.frames<1) throw std::runtime_error("--frames must be positive");
        } else if(argument=="--phase") options.state.phase=std::stof(value(i));
        else if(argument=="--yaw") options.state.yaw=std::clamp(std::stof(value(i)),-80.0f,80.0f);
        else if(argument=="--pitch") options.state.pitch=std::clamp(std::stof(value(i)),0.0f,35.0f);
        else if(argument=="--walk") { options.state.walkInPlace=true; options.state.walkAmount=1; }
        else if(argument=="--paused") options.state.paused=true;
        else if(argument=="--help") {
            std::puts("Dear Human Plan D: native 3D skeleton and rigid procedural meshes\n"
                "1 bones | 2 solid | 3 overlay | arrows move | W walk in place\n"
                "Space pause | Q/E orbit | V side/three-quarter | Up/Down pitch\n"
                "Mouse wheel zoom | R reset | Escape quit\n"
                "Options: --view bones|solid|overlay --walk --paused --phase radians\n"
                "         --yaw degrees --pitch degrees --capture file.png --frames N");
            std::exit(0);
        } else throw std::runtime_error("Unknown option: "+argument);
    }
    if(!options.capture.empty() && options.frames==0) options.frames=3;
    return options;
}
}
int main(int argc,char** argv) {
    try {
        const Options options=parse(argc,argv);
        if(!SDL_Init(SDL_INIT_VIDEO)) throw std::runtime_error(SDL_GetError());
        struct QuitSDL { ~QuitSDL() { SDL_Quit(); } } quit;
        std::unique_ptr<SDL_Window,decltype(&SDL_DestroyWindow)> window(
            SDL_CreateWindow("Dear Human / Plan D",1280,800,SDL_WINDOW_RESIZABLE|SDL_WINDOW_HIGH_PIXEL_DENSITY),SDL_DestroyWindow);
        if(!window) throw std::runtime_error(SDL_GetError());
        SDL_SetWindowMinimumSize(window.get(),800,560);
        dh::Renderer renderer;
        renderer.initialize(window.get());
        dh::Skeleton skeleton;
        auto state=options.state;
        constexpr double step=1.0/120;
        double previous=static_cast<double>(SDL_GetTicksNS())/1e9, accumulated=0;
        bool running=true, captureRequested=false;
        int rendered=0;
        std::puts("Plan D ready. 1 bones / 2 solid / 3 overlay. Space pause. Escape quit.");
        while(running) {
            SDL_Event event;
            while(SDL_PollEvent(&event)) {
                if(event.type==SDL_EVENT_QUIT) running=false;
                if(event.type==SDL_EVENT_KEY_DOWN && !event.key.repeat) {
                    switch(event.key.scancode) {
                    case SDL_SCANCODE_ESCAPE: running=false; break;
                    case SDL_SCANCODE_1: state.view=dh::View::Skeleton; break;
                    case SDL_SCANCODE_2: state.view=dh::View::Solid; break;
                    case SDL_SCANCODE_3: state.view=dh::View::Overlay; break;
                    case SDL_SCANCODE_SPACE: state.paused=!state.paused; break;
                    case SDL_SCANCODE_W: state.walkInPlace=!state.walkInPlace; break;
                    case SDL_SCANCODE_V:
                        if(std::abs(state.yaw)<.1f) { state.yaw=25; state.pitch=12; }
                        else { state.yaw=0; state.pitch=0; }
                        break;
                    case SDL_SCANCODE_R: state=dh::ViewState{}; accumulated=0; break;
                    case SDL_SCANCODE_F12: captureRequested=true; break;
                    default: break;
                    }
                }
                if(event.type==SDL_EVENT_MOUSE_WHEEL)
                    state.zoom=std::clamp(state.zoom+event.wheel.y*.08f,.65f,1.65f);
                if(event.type==SDL_EVENT_MOUSE_BUTTON_DOWN && event.button.button==SDL_BUTTON_LEFT) {
                    int lw=0,lh=0;
                    SDL_GetWindowSize(window.get(),&lw,&lh);
                    const float ui=std::min(static_cast<float>(lw)/1280,static_cast<float>(lh)/800);
                    const float x=event.button.x/ui, y=event.button.y/ui;
                    if(y>=122 && y<=152 && x>=28 && x<490) {
                        const int tab=static_cast<int>((x-28)/158);
                        if(tab<3 && x<28+tab*158+146) state.view=static_cast<dh::View>(tab);
                    }
                }
            }
            if(!running) break;
            const double now=static_cast<double>(SDL_GetTicksNS())/1e9;
            const double elapsed=std::clamp(now-previous,0.0,.1);
            previous=now;
            const bool active=(SDL_GetWindowFlags(window.get())&SDL_WINDOW_INPUT_FOCUS)!=0;
            const bool* keys=SDL_GetKeyboardState(nullptr);
            const float axis=active?static_cast<float>(keys[SDL_SCANCODE_RIGHT])-static_cast<float>(keys[SDL_SCANCODE_LEFT]):0;
            const float orbit=active?static_cast<float>(keys[SDL_SCANCODE_E])-static_cast<float>(keys[SDL_SCANCODE_Q]):0;
            const float pitch=active?static_cast<float>(keys[SDL_SCANCODE_UP])-static_cast<float>(keys[SDL_SCANCODE_DOWN]):0;
            // Camera and view modes remain adjustable while the pose is paused.
            state.yaw=std::clamp(state.yaw+orbit*static_cast<float>(elapsed)*50,-80.0f,80.0f);
            state.pitch=std::clamp(state.pitch+pitch*static_cast<float>(elapsed)*25,0.0f,35.0f);
            if(state.paused) accumulated=0;
            else accumulated+=elapsed;
            while(accumulated>=step) {
                const float target=(std::abs(axis)>.1f || state.walkInPlace)?1.0f:0.0f;
                state.walkAmount+=(target-state.walkAmount)*std::min(1.0f,static_cast<float>(step)*12);
                if(std::abs(axis)>.1f) state.facing=axis;
                state.worldX+=axis*.9f*static_cast<float>(step);
                if(state.walkAmount>.001f) state.phase=std::fmod(state.phase+static_cast<float>(step)*2*dh::pi*1.15f,2*dh::pi);
                accumulated-=step;
            }
            int pw=0,ph=0;
            SDL_GetWindowSizeInPixels(window.get(),&pw,&ph);
            if(pw<=0 || ph<=0 || (SDL_GetWindowFlags(window.get())&SDL_WINDOW_MINIMIZED)) { SDL_Delay(16); continue; }
            skeleton.pose(state.phase,state.walkAmount,state.facing,state.worldX);
            const auto scene=dh::makeScene(skeleton,state,pw,ph);
            const auto camera=dh::cameraMatrix(state,static_cast<float>(pw)/ph);
            const bool finalFrame=options.frames>0 && rendered+1>=options.frames;
            std::filesystem::path capture;
            if(finalFrame) capture=options.capture;
            if(captureRequested) {
                if(capture.empty()) capture=std::filesystem::current_path()/"captures"/("plan-d-"+std::to_string(SDL_GetTicksNS())+".png");
                captureRequested=false;
            }
            if(renderer.draw(scene,camera,capture)) ++rendered;
            else SDL_Delay(16);
            char title[192];
            std::snprintf(title,sizeof(title),"Dear Human / Plan D / %s / %s / %s",
                renderer.backend(),dh::viewName(state.view),state.paused?"Paused":"Playing");
            SDL_SetWindowTitle(window.get(),title);
            if(options.frames>0 && rendered>=options.frames) running=false;
        }
        return 0;
    } catch(const std::exception& error) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION,"Plan D: %s",error.what());
        return 1;
    }
}
