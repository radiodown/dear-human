#include "SampleWorld.hpp"
#include "CloneModelData.hpp"

namespace dh {
Mat4 SampleWorld::headTransform(const Skeleton& skeleton) {
    return skeleton.world(Head)*model::cloneModel().inverseBind[Head];
}
const char* SampleWorld::hairName() const {return available() && selected_>=0?library_->hair[selected_].name.c_str():"ORIGINAL 004";}
void SampleWorld::sync(const Skeleton& skeleton,const ViewState& state,bool reset) {
    if(!available()) return;
    const int selection=std::clamp(state.hairSample,0,hairCount()-1);
    if(selection!=selected_) {selected_=selection;dynamics_.bind(library_->hair[selected_].mesh,headTransform(skeleton));}
    if(reset || state.hairPhysics!=physics_) dynamics_.reset(headTransform(skeleton));
    if(reset) {time_=0;probePhase_=0;probeOrigin_=state.worldX;probeWasMoving_=false;}
    if(state.probeMoving && !probeWasMoving_) {probePhase_=0;probeOrigin_=state.worldX;}
    probeWasMoving_=state.probeMoving;
    physics_=state.hairPhysics;props_=state.sampleProps;
    updateColliders(skeleton,state);
}
void SampleWorld::updateColliders(const Skeleton& skeleton,const ViewState& state) {
    colliders_.clear();
    // Kinematic body proxies follow the same skeleton, in world coordinates.
    colliders_.push_back({ColliderShape::Ellipsoid,skeleton.position(Head)+Vec3{0,.035f,0},{},{.078f,.123f,.096f},0});
    colliders_.push_back({ColliderShape::Capsule,skeleton.position(Chest)+Vec3{-.015f,-.11f,0},skeleton.position(Neck),{},.10f});
    colliders_.push_back({ColliderShape::Capsule,skeleton.position(LeftShoulder),skeleton.position(LeftElbow),{},.075f});
    colliders_.push_back({ColliderShape::Capsule,skeleton.position(RightShoulder),skeleton.position(RightElbow),{},.075f});
    // A thin torso/cape envelope, not triangle-level cloth contact.
    const auto cape=skeleton.world(Chest).point({-.135f,-.12f,0});
    colliders_.push_back({ColliderShape::Ellipsoid,cape,{},{.045f,.24f,.20f},0});
    const float excursion=state.probeMoving?(.5f-.5f*std::cos(probePhase_)):0;
    probe_={state.boxProbe?ColliderShape::Box:ColliderShape::Sphere,
        {probeOrigin_-.68f+.47f*excursion,1.53f,.075f},{},{.105f,.105f,.105f},.125f};
    if(props_) {
        colliders_.push_back(probe_);
        colliders_.push_back({ColliderShape::Box,{.92f,.24f,0},{},{.24f,.24f,.24f},0});
    }
}
void SampleWorld::step(const Skeleton& skeleton,const ViewState& state,float dt) {
    if(!available()) return;
    time_+=dt;if(state.probeMoving)probePhase_=std::fmod(probePhase_+dt*1.8f,2*pi);
    updateColliders(skeleton,state);
    if(state.hairPhysics && dynamicHair()) dynamics_.step(headTransform(skeleton),dt,time_,state.wind,state.collisions,colliders_);
    else dynamics_.reset(headTransform(skeleton));
}
float SampleWorld::constrainMovement(float oldX,float wantedX) const {
    if(!available() || !props_) return wantedX;
    constexpr float left=.92f-.24f-.19f,right=.92f+.24f+.19f;
    if(oldX<=left && wantedX>left) return left;
    if(oldX>=right && wantedX<right) return right;
    // Re-enabling collision while inside the block has a deterministic nearest exit.
    if(wantedX>left && wantedX<right) return wantedX<(left+right)/2?left:right;
    return wantedX;
}
void SampleWorld::appendHair(MeshData& target,const Skeleton& skeleton,const ViewState& state) const {
    if(!available() || selected_<0) return;
    const auto mesh=dynamics_.deform(library_->hair[selected_].mesh,headTransform(skeleton),state.hairPhysics && dynamicHair());
    appendMesh(target,mesh,Mat4::identity());
}
void SampleWorld::appendProps(MeshData& target) const {
    if(!available() || !props_) return;
    const std::array<Vec3,6> positions{{{.92f,.24f,0},{-.1f,.3f,1.2f},{-.2f,.3f,-1.25f},{-.6f,.15f,.8f},{.4f,.15f,-.72f},{-.5f,1.83f,-1.3f}}};
    const std::array<float,6> sizes{{.48f,.32f,.65f,.55f,.35f,.46f}};
    for(std::size_t i=0;i<library_->props.size();++i) {
        const float size=sizes[i];const Mat4 turn=Mat4::rotateY(i==1?pi/2:0);
        appendMesh(target,library_->props[i].mesh,Mat4::translation(positions[i])*turn*Mat4::scale({size,size,size}));
    }
    if(probe_.shape==ColliderShape::Box)
        appendMesh(target,library_->props[0].mesh,Mat4::translation(probe_.center)*Mat4::scale({.21f,.21f,.21f}));
}
float SampleWorld::maximumOffset(const Skeleton& skeleton) const {return dynamics_.maximumOffset(headTransform(skeleton));}
}
