// Focused sample/physics smoke check. No renderer, network or OS APIs.
#include "Simulation.hpp"
#include <cstdio>
#include <stdexcept>

void require(bool value,const char* message) {if(!value)throw std::runtime_error(message);}
int main(int argc,char** argv) {
    try {
        if(argc!=2)throw std::runtime_error("Pass the runtime sample directory");
        const auto assets=dh::loadSampleLibrary(argv[1]);
        require(assets->hair.size()==6 && assets->props.size()==6,"Missing samples");
        std::puts("sample,vertices,triangles,wind_offset_m,contact_steps,max_proxy_penetration_m");
        for(int index=0;index<6;++index) {
            dh::ViewState state;state.hairSample=index;state.probeMoving=true;
            dh::Simulation sim(state,assets);
            unsigned contacts=0;float offset=0,penetration=0;
            for(int frame=0;frame<480;++frame) {
                sim.advance({},1.0/120);
                contacts+=sim.samples().contacts()>0;
                offset=std::max(offset,sim.hairOffset());
                penetration=std::max(penetration,sim.samples().maximumPenetration());
            }
            const auto rendered=sim.renderFrame(1280,800);
            for(const auto& v:rendered.scene.world.vertices)
                require(std::isfinite(v.position.x)&&std::isfinite(v.position.y)&&std::isfinite(v.position.z),"Nonfinite geometry");
            require(offset<.6f && (assets->hair[index].flexible?offset>.001f:offset==0),"Missing or unstable hair response");
            const auto& hair=assets->hair[index].mesh;
            std::printf("%d,%zu,%zu,%.6f,%u,%.6f\n",index,hair.vertices.size(),hair.indices.size()/3,offset,contacts,penetration);
            dh::InputFrame pause;pause.actions={dh::Action::Pause};sim.advance(pause,0);
            const float frozen=sim.hairOffset();sim.advance({},1);sim.renderFrame(800,600);
            require(sim.hairOffset()==frozen,"Paused/render-only call advanced hair");
        }
        // Same sweep with collision on/off must produce a different surface.
        dh::ViewState state;state.hairSample=0;state.wind=false;state.probeMoving=true;
        dh::Simulation on(state,assets);state.collisions=false;dh::Simulation off(state,assets);
        for(int i=0;i<210;++i) {on.advance({},1.0/120);off.advance({},1.0/120);}
        require(off.samples().maximumPenetration()>on.samples().maximumPenetration()+.005f,"Collision toggle has no effect");
        std::printf("collision penetration on %.6f / off %.6f\n",on.samples().maximumPenetration(),off.samples().maximumPenetration());
        require(off.samples().probePenetration()>on.samples().probePenetration()+.005f,"External sphere does not affect hair");
        std::printf("sphere penetration on %.6f / off %.6f\n",on.samples().probePenetration(),off.samples().probePenetration());
        dh::InputFrame box;box.actions={dh::Action::ProbeShape};on.advance(box,0);off.advance(box,0);
        for(int i=0;i<30;++i) {on.advance({},1.0/120);off.advance({},1.0/120);}
        require(off.samples().probePenetration()>on.samples().probePenetration()+.005f,"External box does not affect hair");
        std::printf("box penetration on %.6f / off %.6f\n",on.samples().probePenetration(),off.samples().probePenetration());
        dh::InputFrame move;move.moveAxis=1;
        for(int i=0;i<240;++i) {on.advance(move,1.0/120);off.advance(move,1.0/120);}
        require(on.state().worldX<=.491f && off.state().worldX>1.5f,"Character/block collision failed");
        std::printf("block stop x %.6f / collision off %.6f\n",on.state().worldX,off.state().worldX);
        std::puts("PASS: sample loading, finite sway, collision difference, block stop, pause/read-only render");
        return 0;
    } catch(const std::exception& e) {std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}
}
